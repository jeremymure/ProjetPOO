package ProjetPOO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author murej
 */
public class Jeu {

    protected String nom;
    protected int ageMinimal;
    protected double prix;


    /*---Constructeur de la classe Jeu---*/
    public Jeu(String n, int ageM, double p) {
        nom = n;
        prix = p;
        ageMinimal = ageM;
    }

    /*---Constructeur par défault de la classe Jeu---*/
    public Jeu() {

    }

    /*---Permet la création d'un nom pour le jeu---*/
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    /*---Permet la création d'un âge minimal pur accèder au jeu---*/
    public int getAgeMinimal() {
        return ageMinimal;
    }

    public void setAgeMinimal(int ageMinimal) {
        this.ageMinimal = ageMinimal;
    }

    /*---Permet la création d'un prix---*/
    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {

        this.prix = prix;

    }

}
