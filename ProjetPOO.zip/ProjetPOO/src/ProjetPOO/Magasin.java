/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetPOO;

import java.util.ArrayList;

/**
 *
 * @author murej
 */
public class Magasin {

    private String nom;
    private Vendeur unVendeur;
    private ArrayList<Jeu> lesJeux = new ArrayList();

    /*---Constructeur de la classe Magasin---*/
    public Magasin(String nom) {
        this.nom = nom;
    }

    /*---Permet de donner un nom au magasin---*/
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    /*---Permet d'assigner un vendeur au magasin---*/
    public Vendeur getUnVendeur() {
        return unVendeur;
    }

    public void setUnVendeur(Vendeur unVendeur) {
        this.unVendeur = unVendeur;
    }

    /*---Permet la création de la liste de jeu présent dans le magasin---*/
    public ArrayList<Jeu> getLesJeux() {
        return lesJeux;
    }

    public void setLesJeux(ArrayList<Jeu> lesJeux) {
        this.lesJeux = lesJeux;
    }

    public void ajouterJeu(Jeu unJeu) {
        this.lesJeux.add(unJeu);
    }
}
