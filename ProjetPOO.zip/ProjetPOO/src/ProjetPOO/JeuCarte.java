/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetPOO;

/**
 *
 * @author murej
 */
public class JeuCarte extends Jeu {

    int nbrCarte;

    /*---Permet d'assigner le nombre de carte présent dans un jeu----*/
    public int getNbrCarte() {
        return nbrCarte;
    }

    public void setNbrCarte(int nbrCarte) {
        this.nbrCarte = nbrCarte;
    }

    /*---Constructeur faisant appel à la classe mère en plus de rajouter le paramètre pion---*/
    public JeuCarte(String nom, int ageMinimal, double prix, int nbrCarte) {
        super(nom, ageMinimal, prix);
        this.nbrCarte = nbrCarte;
    }

    /*---Permet d'avoir la liste d'information sur le jeu---*/
    @Override
    public String toString() {
        return "Jeu de Carte{" + " nom = " + nom + ", ageMinimal = " + ageMinimal + ", prix = " + prix + '}';
    }
}
