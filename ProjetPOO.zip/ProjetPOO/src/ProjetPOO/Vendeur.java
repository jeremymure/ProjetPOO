/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetPOO;

/**
 *
 * @author murej
 */
public class Vendeur {

    private String nom;

    /*---Permet la création du nom d'un vendeur---*/
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    /*---Permet à un vendeur d'ajouter une réduction de 50% un jeu---*/
    public void MoitierPrix(Jeu unJeu) {
        unJeu.setPrix(unJeu.getPrix()/2);
    }
}
