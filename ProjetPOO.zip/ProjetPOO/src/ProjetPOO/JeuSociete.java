/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetPOO;

/**
 *
 * @author murej
 */
public class JeuSociete extends Jeu {
    int nbrPion ;
    
    /*---Permet d'assigner le nombre de pion présent dans un jeu---*/
    public int getNbrPion() {
        return nbrPion;
    }

    public void setNbrPion(int nbrPion) {
        this.nbrPion = nbrPion;
    }
    
    
    /*---Constructeur faisant appel à la classe mère en plus de rajouter le paramètre pion---*/
    public JeuSociete (String nom, int ageMinimal, double prix, int nbrPion){
        super(nom, ageMinimal, prix);
        this.nbrPion = nbrPion;
    }
    
    
    /*---Permet d'avoir la liste d'information sur le jeu---*/
    @Override
    public String toString() {
        return "Jeu de Société{" + " nom = " + nom + ", ageMinimal = " + ageMinimal + ", prix = " + prix + '}';
    }
}
