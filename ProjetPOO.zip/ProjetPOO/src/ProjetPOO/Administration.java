/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetPOO;

/**
 *
 * @author murej
 */
public class Administration {

    public static void main(String[] args) {
    //Initialisation  
        /*---Création de magasin---*/
        Magasin P1 = new Magasin("Le Magasin de Jeu de Société");
        Magasin P2 = new Magasin("Le Magasin de Jeu de Carte");

        /*---Création de jeu de société---*/
        JeuSociete JS1 = new JeuSociete("Carcassonne", 8, 28, 6);
        JeuSociete JS2 = new JeuSociete("Cluedo", 8, 20.14, 6);

        /*---Création de jeu de carte---*/
        JeuCarte JC1 = new JeuCarte("Uno", 7, 14.99, 108);
        JeuCarte JC2 = new JeuCarte("Mille Borne", 6, 20.50, 110);

        /*---Création de vendeu associé à un magasin---*/
        Vendeur V1 = new Vendeur();
        V1.setNom("Jérémy");
        P1.setUnVendeur(V1);

        Vendeur V2 = new Vendeur();
        V2.setNom("Clément");
        P2.setUnVendeur(V2);

        /*---Ajout de jeu au magasin---*/
        P1.ajouterJeu(JS1);
        P1.ajouterJeu(JS2);

        P2.ajouterJeu(JC1);
        P2.ajouterJeu(JC2);

        /*---Utilisation de la fonction MoitierPrix---*/
        V1.MoitierPrix(JS1);
        V2.MoitierPrix(JC2);
        
    //Affichage    
        System.out.println("Dans le magasin nommé " + P1.getNom() + " il y a le vendeur " + P1.getUnVendeur().getNom() + " et les jeux " + P1.getLesJeux());
        System.out.println("Voici la description précise du " + JS1.toString());
        System.out.println("Mais grâce à une réduction de moitié prix, il vous faut " + JS1.getPrix() + " € pour acheter ce jeu.");

        System.out.println("");

        System.out.println("Dans le magasin nommé " + P2.getNom() + " il y a le vendeur " + P2.getUnVendeur().getNom() + " et les jeux " + P2.getLesJeux());
        System.out.println("Voici la description précise du " + JC2.toString());
        System.out.println("Mais grâce à une réduction de moitié prix, il vous faut " + JC2.getPrix() + " € pour acheter ce jeu.");

    }
}
